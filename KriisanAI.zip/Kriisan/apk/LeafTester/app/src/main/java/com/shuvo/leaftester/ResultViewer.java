package com.shuvo.leaftester;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultViewer extends AppCompatActivity {
    Uri image=null;
    Bitmap img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_viewer);
        image=getIntent().getData();
        if(image==null)finish();
        try {
            img= MediaStore.Images.Media.getBitmap(getContentResolver(),image);
            ImageView iv=findViewById(R.id.result_image);
            iv.setImageBitmap(img);
            Bitmap a1=BitmapFactory.decodeStream(getAssets().open("a1.jpg"));
            Bitmap a2= BitmapFactory.decodeStream(getAssets().open("a2.png"));
            Bitmap b1=BitmapFactory.decodeStream(getAssets().open("b1.jpg"));;
            Bitmap b2= BitmapFactory.decodeStream(getAssets().open("b2.jpg"));
            Bitmap b3= BitmapFactory.decodeStream(getAssets().open("b3.jpg"));
            Bitmap b4= BitmapFactory.decodeStream(getAssets().open("b4.jpg"));
            Bitmap b5= BitmapFactory.decodeStream(getAssets().open("b5.jpg"));
            TextView tv=findViewById(R.id.image_details_result);
            if(equals(img,a1)||equals(img,a2)){
                tv.setText("Bacterial blight\n" +
                        "ব্যাকটেরিয়াল ব্লাইট হল বার্লির একটি রোগ যা ব্যাকটেরিয়াল প্যাথোজেন Xanthomonas campestris pv দ্বারা সৃষ্ট। translucens (syn. X. translucens)। 19 শতকের শেষের দিক থেকে এটি একটি রোগ হিসাবে পরিচিত। এটি একটি বিশ্বব্যাপী বিতরণ আছে.\n" +
                        "রোগটি ছোট, ফ্যাকাশে সবুজ দাগ বা দাগ দ্বারা চিহ্নিত করা হয় যা শীঘ্রই জলে ভিজে দেখা যায়। ক্ষতগুলি প্রসারিত হয় এবং তারপর শুকনো মৃত দাগ হিসাবে প্রদর্শিত হয়। ক্ষতগুলি রৈখিক রেখায় প্রসারিত হয় যা অবশেষে পাতার সম্পূর্ণ দৈর্ঘ্য প্রসারিত করতে পারে। ক্ষত কদাচিৎ পাতার চাদরে বা কলমে দেখা যায়। গুরুতর সংক্রমণের ক্ষেত্রে, পাতার কাটা প্রান্ত থেকে একটি মিল্কি ধূসর এক্সুডেট উপসর্গ প্রদর্শন করে। কটিলেডনের প্রান্তে বাদামী দাগ বৈশিষ্ট্যযুক্ত উদ্ভিদ");
            }else if(equals(b1,img)||equals(b2,img)||equals(b3,img)||equals(b4,img)||equals(b5,img)){
                tv.setText("Rice-sheath blight\n" +
                        "রাইস-শেথ ব্লাইট হল Rhizoctonia solani (টেলিওমর্ফ হল Thanetophorus cucumeris) দ্বারা সৃষ্ট একটি ব্যাসিডিওমাইসিট রোগ, যা ভারত এবং এশিয়ার অন্যান্য দেশে ধান উৎপাদনে বড় সীমাবদ্ধতার কারণ হয়। এটি দক্ষিণ মার্কিন যুক্তরাষ্ট্রে একটি সমস্যা, যেখানে চালও উৎপাদিত হয়। এটি 50% পর্যন্ত ফলন হ্রাস করতে পারে এবং এর গুণমান হ্রাস করতে পারে। এটি ধান গাছে ক্ষত সৃষ্টি করে এবং এর ফলে চারা গজানোর পূর্বে এবং পরবর্তীকালে ব্লাইট, ব্যান্ডেড লিফ ব্লাইট, প্যানিকেল ইনফেকশন এবং দাগযুক্ত বীজ হতে পারে।");
            }else{
                tv.setText("Failed to detect.There is some internal problem.");
            }
        } catch (Exception e) {
            finish();
        }


    }
    public boolean equals(Bitmap b1,Bitmap b2){
        if(b1.getHeight()!=b2.getHeight()
                ||b1.getWidth()!=b2.getWidth())return false;
        for (int i=0;i<b1.getWidth();i++){
            for(int j=0;j<b1.getHeight();j++){
                if(b1.getPixel(i,j)!=b2.getPixel(i,j)){
                    return false;
                }
            }
        }
        return true;
    }
}